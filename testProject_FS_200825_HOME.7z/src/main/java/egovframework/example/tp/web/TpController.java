package egovframework.example.tp.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import egovframework.example.tp.service.BoardVO;
import egovframework.example.tp.service.TpDefaultVO;
import egovframework.example.tp.service.TpService;
import egovframework.example.tp.service.UserVO;
import egovframework.example.tp.service.impl.TpDAO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class TpController {

	@Autowired
	TpService tpService;
	
	@RequestMapping(value = "/newIndex.do")
	public String newIndex(ModelMap model) {
		return "tp/newIndex";
	}
	
	@RequestMapping(value = "/joinForm.do")
	public String joinForm(ModelMap model) {
		return "tp/joinForm";
	}
	
	@RequestMapping(value = "/insertUser.do")
	public String insertUser(ModelMap model, UserVO uvo) throws Exception {
		tpService.insertUser(uvo);
		return "tp/newIndex";
	}
	
	@RequestMapping(value = "/loginUser.do")
	public ModelAndView loginUser(ModelMap model, UserVO uvo, HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		int n = tpService.checkUserLogin(uvo);
		if(n == 1) {
			UserVO checkUvo = tpService.selectUserInfo(uvo);
			request.getSession().setAttribute("whoSession", checkUvo);
			mav.setViewName("redirect:mainPage.do");
		}else if(n == 0){
			mav.setViewName("redirect:newIndex.do");
		}
		return mav;
	}
	
	@RequestMapping(value = "/mainPage.do")
	public String mainPage(@ModelAttribute("searchVO") TpDefaultVO searchVO,ModelMap model) throws Exception {
		
		/** pageing setting */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		List<BoardVO> checkBvo = tpService.selectBoardList(searchVO);
		model.addAttribute("boardList",checkBvo);
		
		List<BoardVO> nCheckY = tpService.selectNoticeArticleList();
		model.addAttribute("boardNoticeList",nCheckY);
		
		int totCnt = tpService.selectBoardListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		
		return "tp/mainPage";
	}
	
	@RequestMapping(value = "/insertArticlePage.do")
	public String insertArticlePage(ModelMap model) {
		return "tp/insertArticlePage";
	}
	
	@ResponseBody
	@RequestMapping(value = "/insertArticle.do")
	public void insertArticle(ModelMap model, BoardVO bvo) throws Exception { 
		tpService.insertArticle(bvo);
	}
	
	@RequestMapping(value = "/selectArticleOne.do")
	public String selectArticleOne(ModelMap model, BoardVO bvo) throws Exception {
		BoardVO checkBvo = tpService.selectArticleOne(bvo);
		model.addAttribute("boardList", checkBvo);
		return "tp/selectArticleOne";
	}
	 
	@ResponseBody
	@RequestMapping(value = "/selectArticleUpdate.do")
	public void selectArticleUpdate(ModelMap model, BoardVO bvo) throws Exception{
		tpService.selectArticleUpdate(bvo);
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectArticleDelete.do")
	public void selectArticleDelete(ModelMap model, BoardVO bvo) throws Exception{
		tpService.selectArticleDelete(bvo);
	}
	
	@RequestMapping(value = "/logout.do")
	public String logout(ModelMap model, HttpServletRequest request) {
		request.getSession().removeAttribute("whoSession");
		return "redirect:newIndex.do";
	}
	
	@RequestMapping(value = "/functionSubmit.do")
	public String functionSubmit(@ModelAttribute("searchVO") TpDefaultVO searchVO,ModelMap model) throws Exception {
		/** pageing setting */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		List<BoardVO> checkBvo = tpService.selectBoardList(searchVO);
		model.addAttribute("boardList",checkBvo);
		
		List<BoardVO> nCheckY = tpService.selectNoticeArticleList();
		model.addAttribute("boardNoticeList",nCheckY);
		
		int totCnt = tpService.selectBoardListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		
		return "tp/functionSubmit";
	}
	
	@RequestMapping(value = "/cookieTest.do")
	public String cookieTest(ModelMap model) throws Exception{
		return "tp/cookieTest";
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectUserIdCheck.do")
	public String selectUserIdCheck(ModelMap model, UserVO uvo) throws Exception{
		int n = tpService.selectUserIdCheck(uvo);
		return Integer.toString(n);
	}
}
