package egovframework.example.tp.service.impl;

public class TpMapper {

}
