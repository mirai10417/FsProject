package egovframework.example.tp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.tp.service.BoardVO;
import egovframework.example.tp.service.TpDefaultVO;
import egovframework.example.tp.service.TpService;
import egovframework.example.tp.service.UserVO;

@Service("tpService")
public class TpServiceImpl implements TpService {

	@Autowired
	TpDAO tpDAO;
	
	@Autowired
	TpService tpService;

	@Override
	public void insertUser(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		tpDAO.insertUser(vo);
	}

	@Override
	public int checkUserLogin(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.checkUserLogin(vo);
	}

	@Override
	public List<BoardVO> selectBoardList(TpDefaultVO searchVO) throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.selectBoardList(searchVO);
	}

	@Override
	public int findbNo() throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.findbNo();
	}

	@Override
	public void insertArticle(BoardVO vo) throws Exception {
		int n = tpService.findbNo();
		vo.setBno(n);
		vo.setBwriter("윤현수");
		tpDAO.insertArticle(vo);
		// TODO Auto-generated method stub
	}

	@Override
	public BoardVO selectArticleOne(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		tpService.selectArticleHitUpdate(vo);
		return tpDAO.selectArticleOne(vo);
	}

	@Override
	public void selectArticleUpdate(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		tpDAO.selectArticleUpdate(vo);
	}

	@Override
	public void selectArticleDelete(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		tpDAO.selectArticleDelete(vo);
	}

	@Override
	public void selectArticleHitUpdate(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		tpDAO.selectArticleHitUpdate(vo);
	}

	@Override
	public int selectBoardListTotCnt(TpDefaultVO searchVO) throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.selectBoardListTotCnt(searchVO);
	}

	@Override
	public UserVO selectUserInfo(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.selectUserInfo(vo);
	}

	@Override
	public List<BoardVO> selectNoticeArticleList() throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.selectNoticeArticleList();
	}

	@Override
	public int selectUserIdCheck(UserVO vo) throws Exception {
		// TODO Auto-generated method stub
		return tpDAO.selectUserIdCheck(vo);
	}
}
