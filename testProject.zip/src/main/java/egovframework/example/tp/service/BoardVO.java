package egovframework.example.tp.service;

public class BoardVO {
	private int bno;
	private String bwriter;
	private String btitle;
	private String bcontent;
	private String bdate;
	private int hit;
	private String ncheck;
	
	public BoardVO() {
		// TODO Auto-generated constructor stub
	}

	public int getBno() {
		return bno;
	}

	public void setBno(int bno) {
		this.bno = bno;
	}

	public String getBwriter() {
		return bwriter;
	}

	public void setBwriter(String bwriter) {
		this.bwriter = bwriter;
	}

	public String getBtitle() {
		return btitle;
	}

	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}

	public String getBcontent() {
		return bcontent;
	}

	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}

	public String getBdate() {
		return bdate;
	}

	public void setBdate(String bdate) {
		this.bdate = bdate;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public String getNcheck() {
		return ncheck;
	}

	public void setNcheck(String ncheck) {
		this.ncheck = ncheck;
	}

	
	
	
}
